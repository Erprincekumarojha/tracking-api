package com.app.tracking.service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.app.tracking.generator.TrackingNumberGenerator;
import com.app.tracking.model.TrackingResponse;

@Service
public class TrackingService {

	private final Set<String> generated = ConcurrentHashMap.newKeySet();

	public TrackingResponse generateTrackingNumber(String origin, String destination, BigDecimal weight,
			String createdAt, UUID customerId, String customerName, String customerSlug) {
		String trackingNumber;
		int attempt = 0;
		do {
			trackingNumber = TrackingNumberGenerator.generate(origin, destination, customerSlug, attempt++);
		} while (!generated.add(trackingNumber));

		return new TrackingResponse(trackingNumber, OffsetDateTime.now().toString());
	}
}
