package com.app.tracking.generator;

public class TrackingNumberGenerator {

	public static String generate(String origin, String destination, String slug, int salt) {
		String base = origin + destination + slug.replace("-", "").toUpperCase() + salt;
		String hash = Integer.toHexString(base.hashCode()).toUpperCase().replaceAll("[^A-Z0-9]", "");
		return hash.length() > 16 ? hash.substring(0, 16) : String.format("%-16s", hash).replace(' ', 'X');
	}
}
